//
//  ScrollViewController.m
//  scrollViewXibConstraint
//
//  Created by zly on 2018/2/27.
//  Copyright © 2018年 otto. All rights reserved.
//

#import "ScrollViewController.h"

@interface ScrollViewController ()
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *scrollHeight;
@property (strong, nonatomic) IBOutlet UIView *mainView;

@end

@implementation ScrollViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.scrollHeight.constant = 1500;
    for (NSInteger i = 0; i < 100; i++) {
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(0, i * 35, 375, 30);
        label.text = [NSString stringWithFormat:@"%ld",i];
        label.textColor = [UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.backgroundColor = [UIColor colorWithRed:i*2.5/255.0 green:i*2.5/255.0 blue:i*2.5/255.0 alpha:1];
        [self.mainView addSubview:label];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
